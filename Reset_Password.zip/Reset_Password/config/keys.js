dbPassword = 'mongodb+srv://vinothak:' + encodeURIComponent('aaCeM2dkATYlx2xL') + '@cluster0.cf7ns.mongodb.net/test?retryWrites=true';

module.exports = {
    mongoURI: dbPassword
};
